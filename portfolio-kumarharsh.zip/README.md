# Kumar Harsh – Portfolio

Welcome to my personal developer portfolio built using **React**, **Tailwind CSS**, and **Framer Motion**.

### 🚀 Live Website
[https://portfolio-kumarharsh.vercel.app](https://portfolio-kumarharsh.vercel.app)

### 🔧 Tech Stack

- **React**
- **Tailwind CSS**
- **Framer Motion**
- **Vercel** for Deployment

### 🧠 Sections

- **Home** – Introduction and tagline
- **About Me** – My background and skills
- **Projects** – Featured work
- **Education** – Academic details
- **Internships** – Real-world experience
- **Certifications** – Credentials and recognitions
- **Extras** – Leadership and community involvement
- **Contact** – Get in touch

### 📦 Installation

```bash
git clone https://github.com/your-username/portfolio-kumarharsh.git
cd portfolio-kumarharsh
npm install
npm run dev
```

### 📬 Contact

**Email**: kumarharsh4325@gmail.com  
**Phone**: +91-7488124325  
**Location**: Jehanabad, Bihar  
