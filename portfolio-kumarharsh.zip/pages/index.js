// Main app entrypoint (React Component)
